package views;
import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import models.*
;
public class ContactView extends JFrame {

	// component references
	private JTextField txtFirstName, txtLastName, txtPhoneNumber, txtSearch;
	private JButton btnAdd, btnUpdate, btnDelete, btnSearch, btnLogout, btnEmail;
	private JList<String> contactList;
	private DefaultListModel<String> listModel;
	private int userId;
	
	public ContactView(int userId) {
		
		this.userId = userId;
		
		setTitle("Phonebook");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		listModel = new DefaultListModel<>();
		setContactList(new JList<>(listModel));
		
		//fields and button references
		txtFirstName = new JTextField(20);
		txtLastName = new JTextField(20);
		txtPhoneNumber = new JTextField(20);
		txtSearch = new JTextField(20);
		btnAdd = new JButton("Add");
		btnEmail = new JButton("Email");
		btnUpdate = new JButton("Update");
		btnDelete = new JButton("Delete");
		btnSearch = new JButton("Search");
		btnLogout = new JButton("Logout");
		contactList = new JList<String>();
		contactList.setModel(listModel);
		
		//input Panel
		JPanel inputPanel = new JPanel();
		inputPanel.setLayout(new GridLayout(4,2));
		inputPanel.add(new JLabel("First Name:"));
		inputPanel.add(txtFirstName);
		inputPanel.add(new JLabel("Last Name:"));
		inputPanel.add(txtLastName);
		inputPanel.add(new JLabel("Phone Number:"));
		inputPanel.add(txtPhoneNumber);
		inputPanel.add(btnAdd);
		inputPanel.add(btnUpdate);
		
		//List Panel
		JPanel listPanel = new JPanel(new GridLayout(5,1));
		listPanel.add(btnEmail);
		listPanel.add(new JLabel("Search:"));
		listPanel.add(txtSearch);
		listPanel.add(new JLabel("Contact List:"));
		listPanel.add(new JScrollPane(getContactList()));
		
		//button panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(btnSearch);
		buttonPanel.add(btnDelete);
		buttonPanel.add(btnLogout);
		
		//Add panels to screen
		setLayout(new BorderLayout());
		add(inputPanel, BorderLayout.NORTH);
		add(listPanel, BorderLayout.CENTER);
		add(buttonPanel, BorderLayout.SOUTH);
		
		
		pack();
		setLocationRelativeTo(null);
	}
	
	//action listeners
	public void addAddButtonListener(ActionListener listener) {
		btnAdd.addActionListener(listener);
	}
	
	public void addUpdateButtonListener(ActionListener listener) {
		btnUpdate.addActionListener(listener);
	}
	
	public void addDeleteButtonListener(ActionListener listener) {
		btnDelete.addActionListener(listener);
	}
	
	public void addSearchButtonListener(ActionListener listener) {
		btnSearch.addActionListener(listener);
	}
	
	public void addLogoutButtonListener(ActionListener listener) {
		btnLogout.addActionListener(listener);
	}
	
	public void addContactListListener(ListSelectionListener listener) {
		contactList.addListSelectionListener(listener);
	}
	
	public void addEmailButtonListener(ActionListener listener) {
		btnEmail.addActionListener(listener);
	}
	
	public JTextField getFirstNameField() {
		return txtFirstName;
	}
	
	public JTextField getLastNameField() {
		return txtLastName;
	}
	
	public JTextField getPhoneNumberField() {
		return txtPhoneNumber;
	}
	
	public JTextField getSearchField() {
		return txtSearch;
	}
	
	// getters
	public String getFirstName() {
		return getFirstNameField().getText();
	}
	
	public String getLastName() {
		return getLastNameField().getText();
	}
	
	public String getPhoneNumber() {
		return getPhoneNumberField().getText();
	}
	
	public String getSearch() {
		return getSearchField().getText();
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setContactsToModel(List<Contact> contacts) {
		listModel.clear();
		
		for (Contact c: contacts) {
			listModel.addElement(c.getFirstName() + "\t\t " + c.getLastName() + "\t\t - " + c.getPhoneNumber());
		}
	}
	
	public void setContactList(JList<String> contactList) {
		this.contactList = contactList;
	}
	
	public void searchAndHighlight(String text) {
        for (int i = 0; i < listModel.size(); i++) {
        	if (listModel.getElementAt(i).equals(text)) {
                contactList.setSelectedIndex(i);
                contactList.ensureIndexIsVisible(i);
            }
        }
    }
	
	public JList<String> getContactList() {
		return contactList;
	}
}
