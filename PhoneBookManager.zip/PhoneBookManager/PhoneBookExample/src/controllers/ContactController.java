package controllers;
import models.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.event.*;

import views.*;
import javax.mail.*; 
import javax.mail.internet.*; 
import javax.activation.*; 
import javax.mail.Session; 
import javax.mail.Transport; 


public class ContactController {

	ContactView cv;
	
	public ContactController(ContactView contactView) {
		this.cv = contactView;
		
		updateContactList();
		
		cv.addAddButtonListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Contact contact = new Contact();
				contact.setFirstName(cv.getFirstName());
				contact.setLastName(cv.getLastName());
				contact.setPhoneNumber(cv.getPhoneNumber());
				contact.setUser(cv.getUserId());
				
				if (cv.getFirstName().isEmpty() || cv.getLastName().isEmpty() || cv.getPhoneNumber().isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
		            return; // Stop further execution
		        }
				
				ContactDataAccess contactData = new ContactDataAccess();
				if (contactData.addContact(contact)) {
					JOptionPane.showMessageDialog(null, "Contact added Successfully");
					updateContactList();
				}
				else {
					JOptionPane.showMessageDialog(null, "An Error Has Occured when adding Contact");
				}
			}
		});
		
		cv.addContactListListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				Contact contact = getSelectedContact();
				if (contact != null) {
					updateFields(contact);
				}
			}
		});
		
		cv.addUpdateButtonListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Contact contact = getSelectedContact();
				
				String fName = cv.getFirstName();
				String lName = cv.getLastName();
				String pNum = cv.getPhoneNumber();
				
				contact.setFirstName(fName);
				contact.setLastName(lName);
				contact.setPhoneNumber(pNum);
				
				if (new ContactDataAccess().updateContact(contact)) {
					JOptionPane.showMessageDialog(null, "Contact updated Successfully");
					updateContactList();
				}
			}
		});
		
		cv.addLogoutButtonListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserDataAccess.currentUserID = 0;
				
				cv.setVisible(false);
				
				LoginView lv = new LoginView();
				lv.setVisible(true);
				new LoginController(lv);
			}
		});
		
		cv.addSearchButtonListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ContactDataAccess data = new ContactDataAccess();
				
				List<Contact> contacts = data.getContacts();
				
				if (cv.getSearch().isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Please fill in Search field", "Error", JOptionPane.ERROR_MESSAGE);
		            return; // Stop further execution
		        }
				
				for (Contact c: contacts) {
					if (c.getLastName().equals(cv.getSearch())) {
						updateFields(c);
						cv.searchAndHighlight(cv.getFirstName() + "\t\t " + cv.getLastName() + "\t\t - " + cv.getPhoneNumber());
						return;
					};
				}
				JOptionPane.showMessageDialog(null, "Contact Not in Database");
			}
		});
		
		cv.addDeleteButtonListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Contact contact = getSelectedContact();
				
				ContactDataAccess data = new ContactDataAccess();
				
				data.deleteContact(contact);
				
				updateContactList();
				
				cv.getFirstNameField().setText("");
				cv.getLastNameField().setText("");
				cv.getPhoneNumberField().setText("");
			}
		});
		
		cv.addEmailButtonListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ContactDataAccess data = new ContactDataAccess();
				String sender = "PhoneBook@gmail.com";
				String email = JOptionPane.showInputDialog("Email to Send CSV");
				data.writeCSVFile("output.csv");
				String host = "localhost";
				Properties properties = new Properties();
				properties.put("mail.smtp.auth", "true");
				properties.put("mail.smtp.starttls.enable", "true");  // Use SSL if available
				properties.put("mail.smtp.host", "smtp.gmail.com");
				properties.put("mail.smtp.port", "587"); // Standard port for TLS
				
				Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
				    protected PasswordAuthentication getPasswordAuthentication() {
				        return new PasswordAuthentication("phonebook523@gmail.com", "oxub sysc mpsw uhbc"); // Use your Gmail and app password
				    }
				});
				
				try {
					MimeMessage message = new MimeMessage(session);
					message.setFrom(new InternetAddress(sender));
					message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(email, false));
					message.setSubject("CSV of Contacts");
					BodyPart messageBodyPart = new MimeBodyPart();
					String outputFile = "output.csv";
					DataSource source = new FileDataSource(outputFile);
					messageBodyPart.setDataHandler(new DataHandler(source));
					messageBodyPart.setFileName(outputFile);
					Multipart multipartObject = new MimeMultipart();
					multipartObject.addBodyPart(messageBodyPart);
					message.setContent(multipartObject);
					Transport.send(message);
				}
				catch (MessagingException mex) {
					mex.printStackTrace();
				}
				
			}
		});
	}
	
	private void updateContactList() {
		ContactDataAccess data = new ContactDataAccess();
		
		List<Contact> contacts = data.getContacts();
			
		cv.setContactsToModel(contacts);
	}
	
	private Contact getSelectedContact() {
		Contact contact = null;
		
		int row = cv.getContactList().getSelectedIndex();
		
		if (row != -1) {
			contact = new ContactDataAccess().getContacts().get(row);
		}
		
		return contact;
	}
	
	private void updateFields(Contact contact) {
		cv.getFirstNameField().setText(contact.getFirstName());
		cv.getLastNameField().setText(contact.getLastName());
		cv.getPhoneNumberField().setText(contact.getPhoneNumber());
		
	}
}
