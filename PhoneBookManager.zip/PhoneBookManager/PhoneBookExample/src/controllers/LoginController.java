package controllers;

import java.awt.event.*;

import javax.swing.JOptionPane;

import models.UserDataAccess;
import views.*;

public class LoginController {

	LoginView loginView;
	
	public LoginController(LoginView loginView) {
		
		this.loginView = loginView;
		
		loginView.addRegisterButtonListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
//				RegisterView rv = new RegisterView();
//				rv.setVisible(true);
//				
				loginView.setVisible(false);
				
				RegisterView rv = new RegisterView();
				RegisterContoller rc = new RegisterContoller(rv);
				//rv.setLocationRelativeTo(null);
				rv.setVisible(true);
			}
		});
		
		loginView.addLoginButtonListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
				UserDataAccess userData = new UserDataAccess();
				
				if (loginView.getUsername().isEmpty() || loginView.getPassword().isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
		            return; // Stop further execution
		        }
				
				if (userData.loginUser(loginView.getUsername(), loginView.getPassword())) {
					loginView.setVisible(false);
					
					ContactView contactview = new ContactView(userData.currentUserID);
					ContactController contactController = new ContactController(contactview);
					contactview.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(null, "Username or Password is incorrect");
				}
			}
		});
	}
}
