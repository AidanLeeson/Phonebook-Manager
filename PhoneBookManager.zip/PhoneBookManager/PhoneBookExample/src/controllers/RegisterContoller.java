package controllers;

import java.awt.event.*;
import models.*;

import javax.swing.JOptionPane;

import views.*;

public class RegisterContoller {

	private RegisterView registerView;
	
	public RegisterContoller(RegisterView rv) 
	{
		this.registerView = rv;
		
		registerView.addRegisterButtonListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (registerView.getUsername().isEmpty() || registerView.getPassword().isEmpty() || registerView.getConfirmPassword().isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
		            return; // Stop further execution
		        }
				
				User user = new User();
				user.setUserName(registerView.getUsername());
				user.setPassword(registerView.getPassword());
				
				UserDataAccess uda = new UserDataAccess();
				if (uda.checkUser(user)) {
					JOptionPane.showMessageDialog(null, "Username already registered");
				}
				else {
					if (registerView.getPassword().equals(registerView.getConfirmPassword())) {
						if (uda.registerUser(user)) {
							JOptionPane.showMessageDialog(null, "Registered successfully");
							ContactView cv = new ContactView(uda.currentUserID);
							ContactController cont = new ContactController(cv);
							registerView.setVisible(false);
							cv.setVisible(true);
						}
						else {
							JOptionPane.showMessageDialog(null, "Registration Failed");
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "Passwords do not match");
					}
					
				}
				
			}
		});
		
		registerView.addLoginButtonListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				LoginView lv = new LoginView();
				LoginController lc = new LoginController(lv);
				
				//lv.setLocationRelativeTo(null);
				lv.setVisible(true);
				
				registerView.setVisible(false);
			}
		});
	}
	
}
