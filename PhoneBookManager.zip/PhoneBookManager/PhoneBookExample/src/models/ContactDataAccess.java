package models;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

import utilities.util;

public class ContactDataAccess {

	private Connection connect;
	
	public ContactDataAccess() {
		try {
			this.connect =  util.getConnection();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public boolean addContact(Contact contact) {
		try {
			String query = "INSERT INTO tb_contacts (fName, lName, telephoneNumber, user) VALUES (?, ?, ?, ?);";
			PreparedStatement stm = connect.prepareStatement(query);
			
			stm.setString(1, contact.getFirstName());
			stm.setString(2, contact.getLastName());
			stm.setString(3, contact.getPhoneNumber());
			stm.setInt(4, contact.getUser());
			
			int row = stm.executeUpdate();
			
			if (row > 0) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (SQLException e) {
			return false;
		}
	}
	
	public List<Contact> getContacts() {
		
		List<Contact> contactList = new ArrayList<>();
		
		try {
			String query = "SELECT * FROM tb_contacts WHERE user = ?;";
			PreparedStatement stm = connect.prepareStatement(query);
			
			stm.setInt(1, UserDataAccess.currentUserID);
			
			ResultSet result = stm.executeQuery();
			
			while (result.next()) {
				int contactId = result.getInt("id");
				String firstName = result.getString("fName");
				String lastName = result.getString("lName");
				String phoneNum = result.getString("telephoneNumber");
				
				Contact contact = new Contact(contactId, firstName, phoneNum, lastName);
				
				contactList.add(contact);
				
			}
		}
		
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return contactList;
	}
	
	public boolean updateContact(Contact contact) {
		try {
			String query = "UPDATE tb_contacts SET fName=?, lName=?, telephoneNumber=? WHERE id=? and user=?;";
			PreparedStatement stm = connect.prepareStatement(query);
			
			stm.setString(1, contact.getFirstName());
			stm.setString(2, contact.getLastName());
			stm.setString(3, contact.getPhoneNumber());
			stm.setInt(4, contact.getId());
			stm.setInt(5, UserDataAccess.currentUserID);
			
			int row = stm.executeUpdate();
			
			if (row > 0) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (SQLException e) {
			return false;
		}
	}
	
	public boolean deleteContact(Contact contact) {
		try {
			String query = "DELETE FROM tb_contacts WHERE id=? and user=?;";
			PreparedStatement stm = connect.prepareStatement(query);
			
			
			stm.setInt(1, contact.getId());
			stm.setInt(2, UserDataAccess.currentUserID);
			
			int row = stm.executeUpdate();
			
			if (row > 0) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (SQLException e) {
			return false;
		}
	}
	
	public void writeCSVFile(String filePath) {
		String[] Headers = {"FirstName","LastName","TelephoneNumber"};
		List<Contact> contacts = getContacts();
		try (FileWriter writer = new FileWriter(filePath)){
			writer.append(String.join(",", Headers)).append("\n");
			
			for (Contact c: contacts) {
				writer.append(c.getFirstName()).append(",").append(c.getLastName()).append(",").append(c.getPhoneNumber()).append("\n");
			}
			
		}
		catch (IOException e) {
			 System.out.println("An error occurred while writing the CSV file.");
	         e.printStackTrace();
		}
	}
}
