package models;

public class Contact {

	private int id, user;
	private String firstName, phoneNumber, lastName;
	
	public Contact() {
		super();
	}
	
	public Contact(int id, String firstName, String phoneNumber, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.phoneNumber = phoneNumber;
		this.lastName = lastName;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}
	
	
}
